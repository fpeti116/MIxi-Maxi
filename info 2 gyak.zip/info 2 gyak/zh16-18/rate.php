<?php
if(!empty($_POST)){

    try {
        $db = new PDO("mysql:host=localhost;dbname=zh16-18","root","");
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        printf('Sikertelen kapcsolódás: ' . $e->getMessage());
        exit;
    }


    //prepared statement
    $film=$_POST["film"]; //zarojelben az input name tagje
        $nev=$_POST["nev"];
        $pontszam=$_POST["szam"];    
        $result = $db->query("SELECT 
                            film.id AS ID
                            FROM
                            film
                            WHERE
                            film.cim = '$film'");
        $row = $result->fetchObject();
        $filmid= $row->ID;
    $statement=$db->prepare("INSERT INTO ertekeles(szerzo,pontszam,film_id) VALUES(:buzi,:buzipontszam,:buziid)");
    $statement->bindParam(':buzi',$nev,PDO::PARAM_STR);
    $statement->bindParam(':buzipontszam',$pontszam,PDO::PARAM_STR);
    $statement->bindParam(':buziid',$filmid,PDO::PARAM_STR);
    $statement->execute();
        //adatok kiolvasasa
        
    
    

    if ($statement){
        header("location:index.php");
    }
}
?>

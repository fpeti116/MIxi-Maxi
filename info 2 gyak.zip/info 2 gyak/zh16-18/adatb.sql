-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema zh16-18
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `zh16-18` ;

-- -----------------------------------------------------
-- Schema zh16-18
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `zh16-18` DEFAULT CHARACTER SET utf8 ;
USE `zh16-18` ;

-- -----------------------------------------------------
-- Table `zh16-18`.`film`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `zh16-18`.`film` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `cim` VARCHAR(45) NULL,
  `ev` INT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `zh16-18`.`ertekeles`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `zh16-18`.`ertekeles` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `szerzo` VARCHAR(45) NULL,
  `pontszam` INT NULL,
  `film_id` INT NOT NULL,
  PRIMARY KEY (`id`, `film_id`),
  INDEX `fk_ertekeles_film_idx` (`film_id` ASC),
  CONSTRAINT `fk_ertekeles_film`
    FOREIGN KEY (`film_id`)
    REFERENCES `zh16-18`.`film` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `zh16-18`.`film`
-- -----------------------------------------------------
START TRANSACTION;
USE `zh16-18`;
INSERT INTO `zh16-18`.`film` (`id`, `cim`, `ev`) VALUES (1, 'Shrek', 2001);
INSERT INTO `zh16-18`.`film` (`id`, `cim`, `ev`) VALUES (2, 'Thor', 2011);
INSERT INTO `zh16-18`.`film` (`id`, `cim`, `ev`) VALUES (3, 'Dűne', 2021);

COMMIT;


-- -----------------------------------------------------
-- Data for table `zh16-18`.`ertekeles`
-- -----------------------------------------------------
START TRANSACTION;
USE `zh16-18`;
INSERT INTO `zh16-18`.`ertekeles` (`id`, `szerzo`, `pontszam`, `film_id`) VALUES (1, 'Attila', 5, 1);
INSERT INTO `zh16-18`.`ertekeles` (`id`, `szerzo`, `pontszam`, `film_id`) VALUES (2, 'Béla', 4, 1);
INSERT INTO `zh16-18`.`ertekeles` (`id`, `szerzo`, `pontszam`, `film_id`) VALUES (3, 'Cecil', 2, 2);
INSERT INTO `zh16-18`.`ertekeles` (`id`, `szerzo`, `pontszam`, `film_id`) VALUES (4, 'Dénes', 3, 2);
INSERT INTO `zh16-18`.`ertekeles` (`id`, `szerzo`, `pontszam`, `film_id`) VALUES (5, 'Erzsi', 4, 2);

COMMIT;

SELECT 
    film.id AS id,
    film.cim AS cim,
    film.ev AS ev,
    COUNT(ertekeles.id) AS db,
    AVG(ertekeles.pontszam) AS atlag
FROM
    film
        LEFT OUTER JOIN
    ertekeles ON ertekeles.film_id = film.id
WHERE
    film.ev > 2005
GROUP BY film.id
ORDER BY film.ev DESC

SELECT 
    ertekeles.szerzo AS szerzo, ertekeles.pontszam AS pontszam
FROM
    ertekeles
WHERE
    ertekeles.film_id = 1

SELECT 
    film.id AS ID
FROM
    film
WHERE
    film.cim = 'Shrek'
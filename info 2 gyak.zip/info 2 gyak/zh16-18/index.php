<?php 
try {
    $db = new PDO("mysql:host=localhost; dbname=zh16-18", "root", "");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    printf("Sikertelen kapcsolódás: " . $e->getMessage());
    exit;
}
?>

<?php 
$result = $db->query("SELECT 
    film.id AS id,
    film.cim AS cim,
    film.ev AS ev,
    COUNT(ertekeles.id) AS db,
    AVG(ertekeles.pontszam) AS atlag
FROM
    film
        LEFT OUTER JOIN
    ertekeles ON ertekeles.film_id = film.id
WHERE
    film.ev > 2005
GROUP BY film.id
ORDER BY film.ev DESC");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zh</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Filmek</h1>
    <p>Farkas Péter, UBZN8Q</p>
    <div class="panelek">

        <?php 
        while($row=$result->fetchObject()):
        ?>


        <div class="filmek">
            <h2 id="filmcim"><?= $row->cim?></h2>
            <p id="megjelenes"><?= $row->ev?></p>


            <?php
            if ($row->db != 0): 
            ?>
                <p><b>Értékelés: </b><?= $row->atlag?> (<?= $row->db?> válasz)</p>
                <ul>



                            <?php 
                            $result1 = $db->query("SELECT 
                            ertekeles.szerzo AS szerzo, ertekeles.pontszam AS pontszam
                            FROM
                            ertekeles
                            WHERE
                            ertekeles.film_id = $row->id");
                            while($row1 = $result1->fetchObject()):
                            ?>
                            <li><b><?= $row1->szerzo ?></b>: <?= $row1->pontszam ?>/5</li>
                            <?php 
                                endwhile 
                            ?>
                            
            </ul>
            <?php 
            else: 
            ?>
            <p><b>Értékelés: </b>0.00 (<?= $row->db?> válasz)</p>
            <p>Nincs értékelés</p>
            <?php 
            endif;
            ?>


            
        </div>



        <?php endwhile ?>





        
    </div>

    <?php 
$result = $db->query("SELECT 
    film.id AS id,
    film.cim AS cim,
    film.ev AS ev,
    COUNT(ertekeles.id) AS db,
    AVG(ertekeles.pontszam) AS atlag
FROM
    film
        LEFT OUTER JOIN
    ertekeles ON ertekeles.film_id = film.id
WHERE
    film.ev > 2005
GROUP BY film.id
ORDER BY film.ev DESC");
?>


    <h3>Értékelés</h3>
    <form action="rate.php" method="post">
        <div>
        <label>Film:</label>
        <select required name="film">

        <?php 
        while($row=$result->fetchObject()):
        ?>

            <option><?= $row->cim?></option>
        <?php endwhile ?>

        </select>
        </div>

    <br>

    <div>
    <label>Név:</label>
    <input type="text" required name="nev">
    </div>
        
    <br>

    <div>
    <label>Pontszám:</label>
    <input type="number" min="1" max="5" required name="szam">
    </div>
        
    <br>

    <div>
    <input type="submit" value="küldés">
    </div>
        
    </form>
</body>
</html>
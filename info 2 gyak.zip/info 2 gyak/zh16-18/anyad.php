<?php
require 'db.php';
session_start();
if (isset($_GET['id'])) {
    //kapcsolodas
    $db = getDb();
    //adatok bekerese
    $id = $_GET['id'];

    $check = $db->prepare("SELECT * FROM nevjegyek WHERE id = :id");
    $check->bindParam(':id', $id, PDO::PARAM_INT);
    $check->execute();
    $numberOfRows = $check->rowCount();
    if ($numberOfRows == 0) {
        echo 'Nincs ilyen id';
        exit;
    }
    
    $id = $_GET['id'];
    $result = $db->query("SELECT * FROM nevjegyek WHERE id = $id");
    $row = $result->fetchObject();
    if ($result->rowCount() != 0):
    $statement = $db->prepare("DELETE FROM nevjegyek  WHERE id=:id");
    $statement->bindParam(':id', $id, PDO::PARAM_INT);
    $result = $statement->execute();
    else:
    header("Location:index.php");
    endif;
    
    if ($result) {
        $_SESSION["message"] = 'sikeres törlés';
    }

    //átirányitas
    header("Location:index.php");
}
?>
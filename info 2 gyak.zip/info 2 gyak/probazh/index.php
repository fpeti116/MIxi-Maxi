<?php
try {
        $db = new PDO("mysql:host=localhost;dbname=probazh","root","");
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        printf('Sikertelen kapcsolódás: ' . $e->getMessage());
        exit;
    }

    $keresoszo=$_GET["aaa"];
if (isset($_GET['aaa'])):
    
    $result = $db->query("SELECT 
    klub.id AS id,
    klub.nev AS klubnev,
    klub.dij AS dij,
    COUNT(tag.id) AS db
FROM
    klub
        INNER JOIN
    tagja ON klub.id = tagja.klub_id
        INNER JOIN
    tag ON tagja.tag_id = tag.id
WHERE
    klub.nev LIKE '%$keresoszo%'
GROUP BY klub.id");
else:
    
$result = $db->query("SELECT 
klub.id AS id,
klub.nev AS klubnev,
klub.dij AS dij,
COUNT(tag.id) AS db
FROM
klub
    INNER JOIN
tagja ON klub.id = tagja.klub_id
    INNER JOIN
tag ON tagja.tag_id = tag.id
GROUP BY klub.id");
endif;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Egyesületek</h1>
    <p>Farkas Péter, UBZN8Q</p>
    <form method="get">
        <div>
        <label>Név: </label>
        <input type="text" name="aaa" required value="<?php if (isset($_GET['aaa'])):?><?= $keresoszo?><?php endif;?>">
        </div>
        <br>
        <div>
            <input type="submit" value="Keres">
        </div>
    </form>
    <br>
    <table class="tablazat">
        <tr id="fejlec">
            <th class="clickable" tabindex="0">Név</th>
            <th class="clickable" tabindex="0">Alapítás éve</th>
            <th class="clickable" tabindex="0">Alapító</th>
            <th class="clickable" tabindex="0">Tagok száma</th>
            <th class="clickable" tabindex="0">Tagsági díj</th>
        </tr>
        <?php 
        
        while($row = $result->fetchObject()):
            $result1 = $db->query("SELECT 
            tagja.csatlakozas AS alapitas, tag.nev AS alapito
            FROM
            klub
                INNER JOIN
            tagja ON klub.id = tagja.klub_id
                INNER JOIN
            tag ON tagja.tag_id = tag.id
            WHERE
            tagja.alapito = 'igen' AND klub.id = $row->id");
            $row1 = $result1->fetchObject()               
        ?>
        <tr>
            <td><?= $row->klubnev?></td>
            <td><?= $row1->alapitas?></td>
            <td><?= $row1->alapito?></td>
            <td><?= $row->db?> tag</td>
            <td><?= $row->dij?> Ft</td>
        </tr>
        <?php 
        endwhile
        ?>
    </table>
</body>
</html>

<script src="script.js"></script> //a body vegere megy
document.addEventListener('DOMContentLoaded', function () {//ide menne a js kód }
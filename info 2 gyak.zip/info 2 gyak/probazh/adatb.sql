-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema probazh
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `probazh` ;

-- -----------------------------------------------------
-- Schema probazh
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `probazh` DEFAULT CHARACTER SET utf8 ;
USE `probazh` ;

-- -----------------------------------------------------
-- Table `probazh`.`klub`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `probazh`.`klub` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nev` VARCHAR(45) NULL,
  `dij` INT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `probazh`.`tag`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `probazh`.`tag` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nev` VARCHAR(45) NULL,
  `szul` DATE NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `probazh`.`tagja`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `probazh`.`tagja` (
  `klub_id` INT NOT NULL,
  `tag_id` INT NOT NULL,
  `alapito` VARCHAR(45) NULL,
  `csatlakozas` INT NULL,
  PRIMARY KEY (`klub_id`, `tag_id`),
  INDEX `fk_klub_has_tag_tag1_idx` (`tag_id` ASC),
  INDEX `fk_klub_has_tag_klub_idx` (`klub_id` ASC),
  CONSTRAINT `fk_klub_has_tag_klub`
    FOREIGN KEY (`klub_id`)
    REFERENCES `probazh`.`klub` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_klub_has_tag_tag1`
    FOREIGN KEY (`tag_id`)
    REFERENCES `probazh`.`tag` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `probazh`.`klub`
-- -----------------------------------------------------
START TRANSACTION;
USE `probazh`;
INSERT INTO `probazh`.`klub` (`id`, `nev`, `dij`) VALUES (1, 'Informatikusok országos szövetsége', 3000);
INSERT INTO `probazh`.`klub` (`id`, `nev`, `dij`) VALUES (2, 'PHP programozók társasága', 4500);
INSERT INTO `probazh`.`klub` (`id`, `nev`, `dij`) VALUES (3, 'CSS kedvelők szövetsége', 2700);
INSERT INTO `probazh`.`klub` (`id`, `nev`, `dij`) VALUES (4, 'SQL adatbázist használók egyesülete', 5000);

COMMIT;


-- -----------------------------------------------------
-- Data for table `probazh`.`tag`
-- -----------------------------------------------------
START TRANSACTION;
USE `probazh`;
INSERT INTO `probazh`.`tag` (`id`, `nev`, `szul`) VALUES (1, 'Gábor', '1975-05-13');
INSERT INTO `probazh`.`tag` (`id`, `nev`, `szul`) VALUES (2, 'Evelin', '1946-12-01');
INSERT INTO `probazh`.`tag` (`id`, `nev`, `szul`) VALUES (3, 'Olívia', '1980-08-18');
INSERT INTO `probazh`.`tag` (`id`, `nev`, `szul`) VALUES (4, 'András', '1981-09-27');
INSERT INTO `probazh`.`tag` (`id`, `nev`, `szul`) VALUES (5, 'Ottó', '1990-01-30');

COMMIT;


-- -----------------------------------------------------
-- Data for table `probazh`.`tagja`
-- -----------------------------------------------------
START TRANSACTION;
USE `probazh`;
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (1, 1, 'igen', 1980);
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (1, 2, 'nem', 1981);
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (1, 3, 'nem', 1990);
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (2, 4, 'igen', 2010);
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (2, 2, 'nem', 2012);
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (3, 3, 'igen', 2017);
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (3, 5, 'nem', 2014);
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (3, 4, 'nem', 2019);
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (3, 2, 'nem', 2020);
INSERT INTO `probazh`.`tagja` (`klub_id`, `tag_id`, `alapito`, `csatlakozas`) VALUES (4, 5, 'igen', 2001);

COMMIT;

select klub.nev as klubnev, klub.dij as dij, count(tag.id) as db from
klub inner join tagja on klub.id=tagja.klub_id 
inner join tag on tagja.tag_id=tag.id
group by klub.id
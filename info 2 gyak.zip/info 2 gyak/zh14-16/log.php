<?php

    try {
        $db = new PDO("mysql:host=localhost;dbname=zh14-16","root","");
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        printf('Sikertelen kapcsolódás: ' . $e->getMessage());
        exit;
    }


    //adatok kiolvasasa
    $varosnev=$_POST["varosnev"];
    $datum=$_POST["datum"];
    $homerseklet=$_POST['hom'];

    $result = $db->query("SELECT 
        varos.id AS id
        FROM
        varos
        WHERE
        varos.nev = '$varosnev'");

    $row = $result->fetchObject();
    $varosid= $row->id;

    
    //prepared statement
    $statement=$db->prepare("INSERT INTO meres(datum,homerseklet,varos_id) VALUES(:buzi1,:buzi2,:buzi3)");
    $statement->bindParam(':buzi1',$varosnev,PDO::PARAM_STR);
    $statement->bindParam(':buzi2',$homerseklet,PDO::PARAM_STR);
    $statement->bindParam(':buzi3',$varosid,PDO::PARAM_STR);

        
    
    $statement->execute();


    header("location:index.php");


?>

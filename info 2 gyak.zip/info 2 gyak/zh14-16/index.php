<?php 
try {
    $db = new PDO("mysql:host=localhost; dbname=zh14-16", "root", "");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    printf("Sikertelen kapcsolódás: " . $e->getMessage());
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Időjárás</h1>
    <p>Farkas Péter, UBZN8Q</p>
    <div class="torzs">
        <div class="tablazat">
            <table>
                <tr>
                    <th>Név</th>
                    <th>Lakosság</th>
                    <th>Átlaghőmérséklet</th>
                </tr>

                <?php 
$result = $db->query("SELECT 
    varos.id AS id,
    varos.nev AS nev,
    varos.lakossag AS lakossag,
    AVG(meres.homerseklet) AS atlag
FROM
    varos
        LEFT OUTER JOIN
    meres ON varos.id = meres.varos_id
WHERE
    varos.lakossag > 1
GROUP BY varos.id
ORDER BY varos.lakossag ASC");

while($row=$result->fetchObject()):

?>

                <tr>
                    <td><?= $row->nev?></td>
                    <td><?= $row->lakossag?> millió fő</td>
                    <td><?= $row->atlag?> °C</td>
                </tr>
                <tr>
                <?php 
                                $result1 = $db->query("SELECT 
                                meres.datum AS datum, meres.homerseklet AS homerseklet
                                FROM
                                meres
                                WHERE
                                meres.varos_id = $row->id");
                                if ($result1->rowCount() != 0):                                      
                            ?>
                    
                    <td colspan="3">
                        <ul>

                            <?php 
                               while($row1 = $result1->fetchObject()):               
                            ?>
            
                            <li><?= $row1->datum?> <?= $row1->homerseklet?> °C</li>

                            <?php 
                                endwhile 
                            ?>
                        </ul>
                    </td>
    
                    <?php 
                    else: 
                    ?>
                        <td colspan="3" id="jelzes">Nincs értékelés</td>
                    
                    <?php 
                    endif;
                    ?>
                    </tr>
                    <?php 
                    endwhile 
                    ?>
            </table>
        </div>


        
        <div class="formok">
            <h2>Időjárás naplózása</h2>
            <form action="log.php" method="post">
                
                <div>
                Város: <select name="varosnev" required>


                            <?php 
            $result = $db->query("SELECT 
    varos.id AS id,
    varos.nev AS nev,
    varos.lakossag AS lakossag,
    AVG(meres.homerseklet) AS atlag
FROM
    varos
        LEFT OUTER JOIN
    meres ON varos.id = meres.varos_id
WHERE
    varos.lakossag > 1
GROUP BY varos.id
ORDER BY varos.lakossag ASC");

            while($row=$result->fetchObject()):

            ?>
                <option><?= $row->nev?></option>
            <?php 
            endwhile 
            ?>
                </select>
                </div>
                <br>
                <div>
                Dátum: <input type="date" name="datum" required>
                </div>
                <br>
                <div>
                Hőmérséklet: <input name="hom" type="number" required min="-10" max="50">
                </div>
                <br>
                <div>
                <input type="submit">
                </div>

            </form>
        </div>
    </div>
</body>
</html>
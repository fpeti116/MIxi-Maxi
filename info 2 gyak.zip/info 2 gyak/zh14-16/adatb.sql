-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema zh14-16
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `zh14-16` ;

-- -----------------------------------------------------
-- Schema zh14-16
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `zh14-16` DEFAULT CHARACTER SET utf8 ;
USE `zh14-16` ;

-- -----------------------------------------------------
-- Table `zh14-16`.`varos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `zh14-16`.`varos` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nev` VARCHAR(45) NULL,
  `lakossag` DECIMAL(3,1) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `zh14-16`.`meres`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `zh14-16`.`meres` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `datum` DATE NULL,
  `homerseklet` INT NULL,
  `varos_id` INT NOT NULL,
  PRIMARY KEY (`id`, `varos_id`),
  INDEX `fk_meres_varos_idx` (`varos_id` ASC) VISIBLE,
  CONSTRAINT `fk_meres_varos`
    FOREIGN KEY (`varos_id`)
    REFERENCES `zh14-16`.`varos` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `zh14-16`.`varos`
-- -----------------------------------------------------
START TRANSACTION;
USE `zh14-16`;
INSERT INTO `zh14-16`.`varos` (`id`, `nev`, `lakossag`) VALUES (1, 'Lodon', 8,9);
INSERT INTO `zh14-16`.`varos` (`id`, `nev`, `lakossag`) VALUES (2, 'Párizs', 2,1);
INSERT INTO `zh14-16`.`varos` (`id`, `nev`, `lakossag`) VALUES (3, 'Budapest', 1,7);

COMMIT;


-- -----------------------------------------------------
-- Data for table `zh14-16`.`meres`
-- -----------------------------------------------------
START TRANSACTION;
USE `zh14-16`;
INSERT INTO `zh14-16`.`meres` (`id`, `datum`, `homerseklet`, `varos_id`) VALUES (1, '2024-11-18', 10, 1);
INSERT INTO `zh14-16`.`meres` (`id`, `datum`, `homerseklet`, `varos_id`) VALUES (2, '2024-11-20', 9, 1);
INSERT INTO `zh14-16`.`meres` (`id`, `datum`, `homerseklet`, `varos_id`) VALUES (3, '2024-11-18', 5, 3);
INSERT INTO `zh14-16`.`meres` (`id`, `datum`, `homerseklet`, `varos_id`) VALUES (4, '2024-11-19', 7, 3);
INSERT INTO `zh14-16`.`meres` (`id`, `datum`, `homerseklet`, `varos_id`) VALUES (5, '2024-11-20', 6, 3);

COMMIT;


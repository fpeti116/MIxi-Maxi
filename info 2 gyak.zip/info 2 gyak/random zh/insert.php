<?php
session_start();

    include 'db.php';
    
    if (!empty($_POST))
    {
        $db = getDB();

        $nev = $_POST['nev'];
        $szam = $_POST['szam'];

        if (empty($nev) || empty($szam))
            {
                $_SESSION['message'] = "Kérlek mindkét adatot add meg! :)";
                header("Location: insert.php");
                exit;
            }
        else
            {
                $statement = $db->prepare("INSERT INTO nevjegyek (nev,szam) VALUES (:nev,:szam)");
                $statement->bindParam(':nev', $nev, PDO::PARAM_STR);
                $statement->bindParam(':szam', $szam, PDO::PARAM_STR);

                $result = $statement->execute();

                if ($result)
                {
                    $_SESSION['message'] = "Sikerült hozzáadni! :)";
                }
                else
                {
                    $_SESSION['message'] = "Nem sikerült hozzáadni! :(";
                }

                header("Location: index.php");
                exit;
            }
    }

?>

<!DOCTYPE html>
<html lang="hu">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Telefonkönyv</title>
    </head>
    <body>
        <form action="insert.php" method="post">
            <h1>Új telefonszám</h1>

            <?php
                if (isset($_SESSION['message'])) 
                {
                    echo '<div>' . $_SESSION['message'] . '</div>';
                    unset($_SESSION['message']);
                }
            ?>

            <p>
                <label>Név: <input type="text" name="nev" /></label>
            </p>
            <p>
                <label>Telefonszám: <input type="text" name="szam" /></label>
            </p>
            <p> 
                <input type="submit" value="Elküld" name="uj" />
            </p>
        </form>
    </body>
</html>


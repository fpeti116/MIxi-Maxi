<?php
session_start();

include 'db.php';

if (!isset($_GET['id']))
{
    $_SESSION['message'] = "Nincsen megadva id.";
    header("Location: index.php");
    exit();
}

if (isset($_GET['id']))
{
    $db = getDb();
    $id =$_GET['id'];
    $statement = $db->prepare("DELETE FROM nevjegyek WHERE id=:id");
    $statement->bindParam(':id', $id, PDO::PARAM_INT);
    
    $result = $statement->execute();

    if ($result)
    {
        $_SESSION['message'] = "Sikerült törölni! :)";
    }
    else
    {
        $_SESSION['message'] = "Nem sikerült törölni! :(";
    }

    header("Location: index.php");
}







//index regi
/*


<!DOCTYPE html>
<html lang="hu">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Telefonkönyv</title>
        <link rel="stylesheet" type="text/css" href="theme.css">   
    </head>
    <body>
        
        <h1>Telefonkönyv</h1>
        <table>
            <tr>
                <th>Név</th>
                <th>Telefon</th>
                <th>Törlés</th>
                <?php while ($row = $result->fetchObject()): ?>
                    <tr>
                        <td>   <?= $row->nev ?> </td>
                        <td>   <?= $row->szam ?> </td>
                        <td><a href="delete.php?id=<?= $row->id ?>">Töröl</a></td>
                    </tr>
                <?php endwhile; ?>      
            </tr> 
        </table>
        <p>
           <a href="insert.php">Új elem beszúrása</a>
        </p>

            <?php
                if (isset($_SESSION['message'])) 
                {
                    echo '<div>' . $_SESSION['message'] . '</div>';
                    unset($_SESSION['message']);
                }
            ?>
        
    </body>
</html>


*/
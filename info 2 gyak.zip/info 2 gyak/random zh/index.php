<?php
    require 'db.php';
    $db = getDb();

    $keres = '';
    if (isset($_POST['nev'])) {
        $keres = $_POST['nev'];
    }
    $keresbovitett='%'.$keres.'%';

    $rendezes = isset($_GET['rendezes']) ? $_GET['rendezes'] : 'EgyNev';

    $select ="SELECT 
        e.EgyNev AS EgyNev,
        e.Alapitas AS Alapitas,
        t.Nev AS AlapitoNev,
        COUNT(j.TagID) AS TagSzam,
        TagDij
    FROM egyesulet e
    LEFT JOIN tag t ON e.Alapito = t.ID
    LEFT JOIN tagja j ON e.ID = j.EgyID
    WHERE e.EgyNev LIKE :keresbovitett
    GROUP BY e.ID
    ORDER BY $rendezes ASC";

    $statement = $db->prepare($select);
    $statement->bindParam(':keresbovitett', $keresbovitett, PDO::PARAM_STR);
    $statement->execute();
    $result = $statement;

    $select2 = "SELECT EgyNev FROM egyesulet";
    $statement = $db->prepare($select2);
    $statement->execute();
    $result2 = $statement->fetchAll(PDO::FETCH_COLUMN);

    $egyNevList = json_encode($result2);
?>

<!DOCTYPE html>
<html lang="hu">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Egyesületek</title>
        <link rel="stylesheet" type="text/css" href="mintazh.css">
    </head>

    <body>
        <h1>Telefonkönyv</h1>
        <p>Thor Vasember, SENDHELP</p>

        <form method="post">
        <label for="nev">Név:</label>
        <input id="nev" type="text" name="nev" value="<?= isset($_POST['nev']) ? htmlspecialchars($_POST['nev']) : '' ?>"/>
        <input type="submit" value="Keres">
        </form>
        <br/>

        <table>
            <tr>
                <th><a href="?rendezes=EgyNev">Név</a></th>
                <th><a href="?rendezes=Alapitas">Alapítás éve</a></th>
                <th><a href="?rendezes=AlapitoNev">Alapító</a></th>
                <th><a href="?rendezes=TagSzam">Tagok száma</a></th>
                <th><a href="?rendezes=TagDij">Tagsági díj</a></th>
                <?php while ($row = $result->fetchObject()): ?>
                    <tr>
                        <td><?= $row-> EgyNev ?> </td>
                        <td><?= $row-> Alapitas ?> </td>
                        <td><?= $row-> AlapitoNev ?> </td>
                        <td><?= $row-> TagSzam ?> tag</td>
                        <td><?= $row-> TagDij ?> Ft</td>
                    </tr>
                <?php endwhile; ?>      
            </tr> 
        </table>

        <script>
        window.onload = function() {
            var egyNevs = <?php echo $egyNevList; ?>;
            alert(egyNevs.join("\n"));
        };
        </script>

    </body>
</html>






DROP SCHEMA IF EXISTS egyesulet;
CREATE SCHEMA egyesulet DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
USE egyesulet;

CREATE TABLE tag (
	ID int primary key AUTO_INCREMENT,
    Nev VarChar(50) not null,
    Szuletett date not null
    );
    
CREATE TABLE egyesulet (
	ID int primary key AUTO_INCREMENT,
    EgyNev VarChar(100) not null,
    Alapitas int not null,
    Alapito int references tag(ID),
    TagDij int
);

CREATE TABLE tagja (
    EgyID int references egyesulet(ID),
    TagID int references tag(ID),
    Csatlakozas int,
    primary key(EgyID, TagID)
);

INSERT INTO tag (Nev, Szuletett) VALUES
('Tamás Evelin', '1946-12-01'),
('Bálint Olívia', '1980-06-18'),
('Kozma Ottó', '1990-01-30'),
('Juhász András', '1981-09-27'),
('Török Gábor', '1975-05-13');

INSERT INTO egyesulet (EgyNev, Alapitas, Alapito, Tagdij) VALUES
('CSS kedvelők szövetsége', 2017, 2, 2700),
('Informatikusok országos szövetsége', 1980, 5, 3000),
('PHP programozók társasága', 2010, 4, 4500),
('SQL adatbázist használók egyesülete', 2001, 3, 5000);

INSERT INTO tagja VALUES
(1, 5, 1980), (1, 1, 1981), (1, 2, 1990),
(2, 4, 2010), (2, 1, 2012),
(3, 2, 2017), (3, 3, 2014), (3, 4, 2019), (3, 1, 2020),
(4, 3, 2001);

SELECT * FROM egyesulet;


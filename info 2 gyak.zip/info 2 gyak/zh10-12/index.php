<?php
try {
        $db = new PDO("mysql:host=localhost;dbname=zh10-12","root","");
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        printf('Sikertelen kapcsolódás: ' . $e->getMessage());
        exit;
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>


    <div>
    <h2>Hírek</h2>
    </div>
    <div>
    <p>Farkas Péter, UBZN8Q</p>
    </div>
    
    <?php 
    $result = $db->query("SELECT 
    hir.id AS id,
    hir.cim AS cim,
    hir.datum AS datum,
    hir.szoveg AS szoveg,
    COUNT(hozzaszolas.id) AS darab
FROM
    hir
        LEFT JOIN
    hozzaszolas ON hozzaszolas.hir_id = hir.id
WHERE
    hir.datum > '2024-11-30'
GROUP BY hir.id
ORDER BY hir.datum ASC");

    while($row=$result->fetchObject()):

    ?>
    <div class="torzs">

        <h2 id="cim"><?= $row->cim?></h2>
        <p id="datum"><?= $row->datum?></p>
        <p><?= $row->szoveg?></p>
        <h3><?= $row->darab?> hozzászólás</h3>



        <?php 
                $result1 = $db->query("SELECT 
                hozzaszolas.szerzo AS szerzo, hozzaszolas.komment AS komment
                FROM
                hozzaszolas
                WHERE
                hozzaszolas.hir_id = $row->id");
                if ($result1->rowCount() != 0):                                      
        ?>
            <ul>
                            <?php 
                               while($row1 = $result1->fetchObject()):               
                            ?>
            
                            <li><b><?= $row1->szerzo?></b>: <?= $row1->komment?></li>

                            <?php 
                                endwhile 
                            ?>
            </ul>
        <?php 
        else: 
        ?>
        Nincs hozzászólás

        <?php 
        endif;
        ?>

        <h3>Új hozzászólás írása</h3>
        <div class="formok">
            <form action="comment.php" method="post">
                <div>
                Név:
                <br>
                <input type="text" name="nev" required>
                </div>
                <br>
                <div>
                Szöveg:
                <br>
                <textarea name="szoveg" required></textarea>
                </div >
                <br>
                <div>
                    <input type="hidden" name="hir_id" value="<?= $row->id ?>">
                    <input type="submit" value="kuldes">
                </div>
                <hr>
            </form>
        </div>
    </div>
    <?php 
        endwhile 
     ?>


</body>
</html>
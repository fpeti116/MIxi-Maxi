<?php

    try {
        $db = new PDO("mysql:host=localhost;dbname=zh10-12","root","");
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        printf('Sikertelen kapcsolódás: ' . $e->getMessage());
        exit;
    }


    //adatok kiolvasasa
    $szoveg=$_POST["szoveg"]; //az input name tagje
    $szerzo=$_POST["nev"];
    $hirid=$_POST['hir_id'];

    /*$result = $db->query("SELECT 
        varos.id AS id
        FROM
        varos
        WHERE
        varos.nev = '$varosnev'");

    $row = $result->fetchObject();
    $varosid= $row->id;
    */
    
    //prepared statement
    $statement=$db->prepare("INSERT INTO hozzaszolas(szerzo,komment,hir_id) VALUES(:buzi1,:buzi2,:buzi3)");
    $statement->bindParam(':buzi1',$szerzo,PDO::PARAM_STR);
    $statement->bindParam(':buzi2',$szoveg,PDO::PARAM_STR);
    $statement->bindParam(':buzi3',$hirid,PDO::PARAM_STR);
    $statement->execute();


    header("location:index.php");


?>
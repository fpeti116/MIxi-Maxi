-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema zh10-12
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `zh10-12` ;

-- -----------------------------------------------------
-- Schema zh10-12
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `zh10-12` DEFAULT CHARACTER SET utf8 ;
USE `zh10-12` ;

-- -----------------------------------------------------
-- Table `zh10-12`.`hir`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `zh10-12`.`hir` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `cim` VARCHAR(45) NULL,
  `datum` DATE NULL,
  `szoveg` VARCHAR(500) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `zh10-12`.`hozzaszolas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `zh10-12`.`hozzaszolas` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `szerzo` VARCHAR(45) NULL,
  `komment` VARCHAR(200) NULL,
  `hir_id` INT NOT NULL,
  PRIMARY KEY (`id`, `hir_id`),
  INDEX `fk_hozzaszolas_hir_idx` (`hir_id` ASC),
  CONSTRAINT `fk_hozzaszolas_hir`
    FOREIGN KEY (`hir_id`)
    REFERENCES `zh10-12`.`hir` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `zh10-12`.`hir`
-- -----------------------------------------------------
START TRANSACTION;
USE `zh10-12`;
INSERT INTO `zh10-12`.`hir` (`id`, `cim`, `datum`, `szoveg`) VALUES (1, 'Levi meleg', '2024-12-05', 'Brit tudósok bebizonyították, hogy igen, Levi actually meleg. Fel volt iratkozva whispertonra, ami meghamisíthatatlan bizonyítéka homoszexualitásának. Persze ezzel semmi gond nincs, mert Ábel éppen a melegeket szereti.');
INSERT INTO `zh10-12`.`hir` (`id`, `cim`, `datum`, `szoveg`) VALUES (2, 'Keresik az ovisokat zaklató pedofilt', '2024-12-01', 'A rendőrség több napja nyomoz az újbudai óvodában gyerekeket molesztáló férfit. Elmondások alapján a kerítéshez állt és a gyerekeket cukorkával próbálta közelebb csábítani magához.');
INSERT INTO `zh10-12`.`hir` (`id`, `cim`, `datum`, `szoveg`) VALUES (3, 'Gatya', '2024-11-11', 'asdfgfdsasdfghdsasghzfdsadfgzhdsdrftgdsadfgtdsdfdsdfgfdsdf');

COMMIT;


-- -----------------------------------------------------
-- Data for table `zh10-12`.`hozzaszolas`
-- -----------------------------------------------------
START TRANSACTION;
USE `zh10-12`;
INSERT INTO `zh10-12`.`hozzaszolas` (`id`, `szerzo`, `komment`, `hir_id`) VALUES (1, 'Levi', 'Így van! Már régóta el akartam mondani.', 1);
INSERT INTO `zh10-12`.`hozzaszolas` (`id`, `szerzo`, `komment`, `hir_id`) VALUES (2, 'Ábel', 'I love you Levi!!! <3  <3  <3', 1);
INSERT INTO `zh10-12`.`hozzaszolas` (`id`, `szerzo`, `komment`, `hir_id`) VALUES (3, 'Ákos', 'Remélem elkapják a rohadékot!', 2);

COMMIT;
